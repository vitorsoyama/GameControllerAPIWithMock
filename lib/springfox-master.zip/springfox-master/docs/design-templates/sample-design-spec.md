## A spec to detail ... 
Briefly, what is being proposed/implemented.

### General Approach
- How will the feature be implemented, at a high-level?
 - What modules will the changes impact?
 - Will there be any public api changes?
 
### Test Coverage 
- Unit, integration, any special edge cases?
