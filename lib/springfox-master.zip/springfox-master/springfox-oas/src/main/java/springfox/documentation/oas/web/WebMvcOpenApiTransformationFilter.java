package springfox.documentation.oas.web;

import javax.servlet.http.HttpServletRequest;

public interface WebMvcOpenApiTransformationFilter extends OpenApiTransformationFilter<HttpServletRequest> {
}
