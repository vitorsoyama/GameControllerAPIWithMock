package springfox.test.contract.oas.bugs;

public enum NumberEnum {
  ONE,
  TWO,
  THREE
}
