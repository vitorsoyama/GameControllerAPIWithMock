package springfox.documentation.schema;

public enum CollectionType {
  SET,
  LIST,
  ARRAY
}
