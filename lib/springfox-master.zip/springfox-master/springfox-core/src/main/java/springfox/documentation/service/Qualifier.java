package springfox.documentation.service;

public enum Qualifier {
  ALL_OF,
  ANY_OF,
  ONE_OF,
  NOT
}
